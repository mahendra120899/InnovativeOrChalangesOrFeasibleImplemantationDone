$.emojiarea.path = 'emoji/img';
$.emojiarea.icons = {
	':angry:': 'angry.png',
	':chador:': 'chador.png',
	':cowgirl:': 'cowgirl.png',
	':fire:': 'fire.png',
	':flushed:': 'flushed.png',
	':heart:': 'heart.png',
	':kiss:': 'kiss.png',
	':kisses:': 'kisses.png',
	':laughing:': 'laughing.png',
	':smile:': 'smile.png',
	':study:': 'study.png',
	':sunglasses:': 'sunglasses.png',
};